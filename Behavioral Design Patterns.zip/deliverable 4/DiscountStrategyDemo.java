// Client code to test checkout with different discount strategies
public class DiscountStrategyDemo {
    public static void main(String[] args) {
        CheckoutSystem checkout = new CheckoutSystem();
        double basePrice = 1000;

        System.out.println("Applying Loyalty Discount:");
        checkout.setStrategy(new LoyaltyDiscount());
        checkout.checkout(basePrice);

        System.out.println("\nApplying Referral Discount:");
        checkout.setStrategy(new ReferralDiscount());
        checkout.checkout(basePrice);

        System.out.println("\nApplying FirstTime Discount:");
        checkout.setStrategy(new FirstTimeDiscount());
        checkout.checkout(basePrice);

        System.out.println("\nApplying Student Discount:");
        checkout.setStrategy(new StudentDiscount());
        checkout.checkout(basePrice);
    }
}
