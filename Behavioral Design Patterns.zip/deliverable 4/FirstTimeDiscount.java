// Concrete Strategy: First Time Discount
public class FirstTimeDiscount implements DiscountStrategy {
    @Override
    public double applyDiscount(double basePrice) {
        return basePrice * 0.80; // 20% off
    }
}
