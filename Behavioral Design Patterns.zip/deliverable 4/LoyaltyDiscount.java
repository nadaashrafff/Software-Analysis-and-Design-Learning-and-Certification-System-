// Concrete Strategy: Loyalty Discount
public class LoyaltyDiscount implements DiscountStrategy {
    @Override
    public double applyDiscount(double basePrice) {
        return basePrice * 0.90; // 10% off
    }
}
