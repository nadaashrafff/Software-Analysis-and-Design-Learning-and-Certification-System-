// Concrete Strategy: Referral Discount
public class ReferralDiscount implements DiscountStrategy {
    @Override
    public double applyDiscount(double basePrice) {
        return basePrice - 50; // Flat 50 off
    }
}
