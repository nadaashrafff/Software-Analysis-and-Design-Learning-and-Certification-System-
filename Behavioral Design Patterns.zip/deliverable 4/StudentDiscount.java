// Concrete Strategy: Student Discount
public class StudentDiscount implements DiscountStrategy {
    @Override
    public double applyDiscount(double basePrice) {
        return basePrice * 0.85; // 15% off
    }
}
