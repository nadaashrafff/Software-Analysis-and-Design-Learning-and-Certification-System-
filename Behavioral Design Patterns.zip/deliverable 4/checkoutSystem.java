// Context Class: Checkout System
public class CheckoutSystem {
    private DiscountStrategy strategy;

    public void setStrategy(DiscountStrategy strategy) {
        this.strategy = strategy;
    }

    public void checkout(double basePrice) {
        double finalPrice = strategy.applyDiscount(basePrice);
        System.out.println("Final price after discount: " + finalPrice);
    }
}
