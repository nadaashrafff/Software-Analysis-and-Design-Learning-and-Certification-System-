
public interface Assessment {
    void displayAssessment();
}