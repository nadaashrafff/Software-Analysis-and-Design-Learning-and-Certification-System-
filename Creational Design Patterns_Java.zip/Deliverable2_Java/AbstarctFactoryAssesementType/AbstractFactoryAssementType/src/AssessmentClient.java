public class AssessmentClient {
    public static void main(String[] args) {
        AssessmentFactory factory = new FinalExamFactory(); // can switch to AssignmentFactory, etc.

        Assessment assessment = factory.createAssessment();
        QuestionType question = factory.createQuestion();

        assessment.displayAssessment();
        question.displayQuestion();
    }
}  
