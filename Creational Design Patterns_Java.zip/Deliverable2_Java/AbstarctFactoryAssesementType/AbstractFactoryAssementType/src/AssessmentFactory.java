public interface AssessmentFactory {
    Assessment createAssessment();
    QuestionType createQuestion();
}