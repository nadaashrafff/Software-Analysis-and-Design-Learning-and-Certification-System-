class Assignment implements Assessment {
    public void displayAssessment() {
        System.out.println("Displaying Assignment Assessment");
    }
}