class AssignmentFactory implements AssessmentFactory {
    public Assessment createAssessment() {
        return new Assignment();
    }

    public QuestionType createQuestion() {
        return new Essay();
    }
}