class Essay implements QuestionType {
    public void displayQuestion() {
        System.out.println("Displaying Essay Question");
    }
}