class FinalExam implements Assessment {
    public void displayAssessment() {
        System.out.println("Displaying Final Exam Assessment");
    }
}
