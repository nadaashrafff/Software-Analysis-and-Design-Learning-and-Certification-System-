class FinalExamFactory implements AssessmentFactory {
    public Assessment createAssessment() {
        return new FinalExam();
    }

    public QuestionType createQuestion() {
        return new TrueFalse();
    }
}