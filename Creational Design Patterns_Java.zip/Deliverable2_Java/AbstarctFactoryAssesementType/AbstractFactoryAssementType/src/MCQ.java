class MCQ implements QuestionType {
    public void displayQuestion() {
        System.out.println("Displaying MCQ Question");
    }
}