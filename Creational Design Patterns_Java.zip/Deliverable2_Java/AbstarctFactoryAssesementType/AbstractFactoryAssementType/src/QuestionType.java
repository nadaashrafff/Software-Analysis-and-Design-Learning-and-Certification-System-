public interface QuestionType {
    void displayQuestion();
}
