class Quiz implements Assessment {
    public void displayAssessment() {
        System.out.println("Displaying Quiz Assessment");
    }
}