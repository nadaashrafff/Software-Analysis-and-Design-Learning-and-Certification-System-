class QuizFactory implements AssessmentFactory {
    public Assessment createAssessment() {
        return new Quiz();
    }

    public QuestionType createQuestion() {
        return new MCQ();
    }
}
