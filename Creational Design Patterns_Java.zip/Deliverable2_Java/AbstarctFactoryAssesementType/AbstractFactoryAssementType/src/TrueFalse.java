class TrueFalse implements QuestionType {
    public void displayQuestion() {
        System.out.println("Displaying True/False Question");
    }
}
