class Button implements Component {
    public void render() {
        System.out.println("Rendering Button Component");
    }
}