// Client
public class ClientUI {
    public static void main(String[] args) {
        UIThemeFactory themeFactory = new LightThemeFactory(); // Change to DarkThemeFactory if needed

        Theme theme = themeFactory.createTheme();
        Component component = themeFactory.createComponent();

        theme.applyTheme();
        component.render();
    }
}