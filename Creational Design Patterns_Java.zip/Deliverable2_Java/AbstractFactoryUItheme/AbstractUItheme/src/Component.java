
// Product Interface: Component
interface Component {
    void render();
}