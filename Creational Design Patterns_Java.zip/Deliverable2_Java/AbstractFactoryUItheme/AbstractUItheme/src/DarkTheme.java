class DarkTheme implements Theme {
    public void applyTheme() {
        System.out.println("Applying Dark Theme");
    }
}