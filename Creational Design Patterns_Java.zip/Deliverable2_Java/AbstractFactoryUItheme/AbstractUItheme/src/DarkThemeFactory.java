class DarkThemeFactory implements UIThemeFactory {
    public Theme createTheme() {
        return new DarkTheme();
    }

    public Component createComponent() {
        return new Button();  // or TextStyle/Menu
    }
}