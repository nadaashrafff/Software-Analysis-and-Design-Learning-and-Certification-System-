// Concrete Products – Themes
class LightTheme implements Theme {
    public void applyTheme() {
        System.out.println("Applying Light Theme");
    }
}