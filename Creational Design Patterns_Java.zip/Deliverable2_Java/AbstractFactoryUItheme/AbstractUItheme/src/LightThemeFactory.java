// Concrete Factories
class LightThemeFactory implements UIThemeFactory {
    public Theme createTheme() {
        return new LightTheme();
    }

    public Component createComponent() {
        return new Menu();  // or Button/TextStyle depending on use
    }
}