// Concrete Products – Components
class Menu implements Component {
    public void render() {
        System.out.println("Rendering Menu Component");
    }
}