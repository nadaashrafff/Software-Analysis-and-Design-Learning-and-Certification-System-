class TextStyle implements Component {
    public void render() {
        System.out.println("Applying Text Style");
    }
}