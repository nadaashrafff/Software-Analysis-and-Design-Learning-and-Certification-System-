
// Product Interface: Theme
public interface Theme {
    void applyTheme();
}