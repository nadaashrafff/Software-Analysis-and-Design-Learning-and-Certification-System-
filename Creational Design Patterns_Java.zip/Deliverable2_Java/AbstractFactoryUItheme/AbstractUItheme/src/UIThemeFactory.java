// Abstract Factory
interface UIThemeFactory {
    Theme createTheme();
    Component createComponent(); // generalization of Menu, Button, etc.
}