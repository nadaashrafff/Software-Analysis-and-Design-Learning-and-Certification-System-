// Abstract Product
abstract class Notification {
    abstract void send(String message);
}

// Concrete Products
class EmailNotification extends Notification {
    @Override
    void send(String message) {
        System.out.println("Sending Email: " + message);
    }
}

class SMSNotification extends Notification {
    @Override
    void send(String message) {
        System.out.println("Sending SMS: " + message);
    }
}

class InAppNotification extends Notification {
    @Override
    void send(String message) {
        System.out.println("Sending In-App Notification: " + message);
    }
}
