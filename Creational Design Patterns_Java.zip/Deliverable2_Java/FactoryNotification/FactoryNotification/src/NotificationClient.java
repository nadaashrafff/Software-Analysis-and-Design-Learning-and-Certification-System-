// Client Code
public class NotificationClient {
    public static void main(String[] args) {
        NotificationFactory emailFactory = new EmailNotificationFactory();
        emailFactory.sendNotification("Welcome to EduCertify! Your course is now live.");

        NotificationFactory smsFactory = new SMSNotificationFactory();
        smsFactory.sendNotification("Reminder: Your class starts in 1 hour!");

        NotificationFactory inAppFactory = new InAppNotificationFactory();
        inAppFactory.sendNotification("New announcement: Don't miss today's live session.");
    }
}
//factory method