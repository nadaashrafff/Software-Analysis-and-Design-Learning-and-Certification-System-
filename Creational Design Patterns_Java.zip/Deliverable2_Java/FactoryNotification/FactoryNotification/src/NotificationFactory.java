
// Abstract Factory:
abstract class NotificationFactory {
    // Factory Method
    abstract Notification createNotification();

    // This method uses the Factory Method to send a notification
    public void sendNotification(String message) {
        Notification notification = createNotification();
        notification.send(message);
    }
}

// Concrete Factories
class EmailNotificationFactory extends NotificationFactory {
    @Override
    Notification createNotification() {
        return new EmailNotification();
    }
}

class SMSNotificationFactory extends NotificationFactory {
    @Override
    Notification createNotification() {
        return new SMSNotification();
    }
}

class InAppNotificationFactory extends NotificationFactory {
    @Override
    Notification createNotification() {
        return new InAppNotification();
    }
}
