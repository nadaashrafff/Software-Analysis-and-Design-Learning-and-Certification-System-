public class CertificationGenerator {

    private static volatile CertificationGenerator instance;
    private String templateFormat;

    // Private constructor
    private CertificationGenerator() {
        // Load or initialize default template
        this.templateFormat = "Certificate awarded to {name} for completing {course}";
    }

    // Thread-safe Singleton accessor
    public static CertificationGenerator getInstance() {
        CertificationGenerator localRef = instance;
        if (localRef == null) {
            synchronized (CertificationGenerator.class) {
                localRef = instance;
                if (localRef == null) {
                    instance = localRef = new CertificationGenerator();
                }
            }
        }
        return localRef;
    }

    // Generate the certificate (in real case, this might create a PDF or HTML)
    public String generateCertificate(String learnerName, String courseName) {
        return templateFormat.replace("{name}", learnerName)
                             .replace("{course}", courseName);
    }
}
//singleton