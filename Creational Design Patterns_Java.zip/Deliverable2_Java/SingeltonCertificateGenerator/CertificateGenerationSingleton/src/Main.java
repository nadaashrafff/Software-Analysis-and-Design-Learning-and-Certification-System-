public class Main {
    public static void main(String[] args) {
        // Get the singleton instance
        CertificationGenerator certificateGenerator = CertificationGenerator.getInstance();

        // Test the certificate generation
        String learnerName = "Aly Zaki";
        String courseName = "Java Programming";
        
        String certificate = certificateGenerator.generateCertificate(learnerName, courseName);
        
        // Print the generated certificate
        System.out.println(certificate);
        
        // Verify Singleton behavior: both references should be the same
        CertificationGenerator anotherReference = CertificationGenerator.getInstance();
        
        // Check if both references point to the same instance
        if (certificateGenerator == anotherReference) {
            System.out.println("Singleton works! Both references point to the same instance.");
        } else {
            System.out.println("Singleton failed! The references are different.");
        }
    }
}