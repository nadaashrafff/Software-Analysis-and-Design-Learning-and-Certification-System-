import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {

    private static volatile DatabaseUtil instance;  // Ensures visibility across threads
    private Connection connection;
    private static final String CONNECTION_URL =
        "jdbc:sqlserver://LAPTOP-PUTEA40I:1433;databaseName=Educertify2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;";

    // Private constructor
    private DatabaseUtil() {
        try {
            connection = DriverManager.getConnection(CONNECTION_URL);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Optimized lazy initialization with double-checked locking
    public static DatabaseUtil getInstance() {
        DatabaseUtil localRef = instance;
        if (localRef == null) {
            synchronized (DatabaseUtil.class) {
                localRef = instance;
                if (localRef == null) {
                    instance = localRef = new DatabaseUtil();
                }
            }
        }
        return localRef;
    }

    public Connection getConnection() {
        return connection;
    }
}
// singleton