import java.sql.SQLException;

public class mainDatabase {
    public static void main(String[] args) {
        // Get the singleton instance of DatabaseUtil
        DatabaseUtil databaseUtil = DatabaseUtil.getInstance();
        
        // Test the database connection
        try {
            // Attempt to get a connection and check if it's valid
            if (databaseUtil.getConnection() != null && !databaseUtil.getConnection().isClosed()) {
                System.out.println("Database connection established successfully.");
            } else {
                System.out.println("Failed to establish database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error checking database connection: " + e.getMessage());
        }
        
        // Verify Singleton behavior: both references should be the same instance
        DatabaseUtil anotherReference = DatabaseUtil.getInstance();
        
        // Check if both references point to the same instance
        if (databaseUtil == anotherReference) {
            System.out.println("Singleton works! Both references point to the same instance.");
        } else {
            System.out.println("Singleton failed! The references are different.");
        }
    }
}