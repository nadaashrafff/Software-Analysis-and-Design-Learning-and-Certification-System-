import java.util.Date;

public class AccountController {

    /**
     * Default constructor
     */
    public AccountController() {
    }

    /**
     * Creates an instructor account.
     * 
     * @param instructorID The instructor ID
     * @param SSN          The Social Security Number
     * @param name         The full name of the instructor
     * @param email        The email address
     * @param gender       The gender of the instructor
     * @param DoB          The date of birth
     */
    public void createInstructor(int instructorID, int SSN, String name, String email, String gender, Date DoB) {
        // Split the full name into first, middle, and last name
        String[] nameParts = name.split(" ");
        String fname = nameParts[0];
        String minit = (nameParts.length > 2) ? nameParts[1] : "";
        String lname = nameParts[nameParts.length - 1];

        // Set a default major (can be modified later if needed)
        String major = "Unknown";

        // Create the Instructor object
        Instructor instructor = new Instructor();
        instructor.setInstructorID(instructorID);
        instructor.setSSN(SSN);
        instructor.setFname(fname);
        instructor.setMinit(minit);
        instructor.setLname(lname);
        instructor.setGender(gender);
        instructor.setMajor(major);
        instructor.setDoB(DoB);
        instructor.setEmail(email);

        // Save the instructor details to the database using InstructorDA
        InstructorDA instructorDA = new InstructorDA();
        boolean isSuccess = instructorDA.saveInstructorDetails(instructor);

        // Print the result
        if (isSuccess) {
            System.out.println("Instructor account created successfully!");
        } else {
            System.out.println("Failed to create instructor account.");
        }
    }

    /**
     * Creates a learner account.
     * 
     * @param learnerID The learner ID
     * @param SSN       The Social Security Number
     * @param name      The full name of the learner
     * @param email     The email address
     * @param gender    The gender of the learner
     * @param DoB       The date of birth
     */
    public void createLearner(int learnerID, int SSN, String name, String email, String gender, Date DoB) {
        // Split the full name into first, middle, and last name
        String[] nameParts = name.split(" ");
        String fname = nameParts[0];
        String minit = (nameParts.length > 2) ? nameParts[1] : "";
        String lname = nameParts[nameParts.length - 1];

        // Create the Learner object
        Learner learner = new Learner();
        learner.setLearnerID(learnerID);
        learner.setSSN(SSN);
        learner.setFname(fname);
        learner.setMinit(minit);
        learner.setLname(lname);
        learner.setGender(gender);
        learner.setDoB(DoB);
        learner.setEmail(email);

        // Save the learner details to the database using LearnerDA
        LearnerDA learnerDA = new LearnerDA();
        boolean isSuccess = learnerDA.saveLearnerDetails(learner);

        // Print the result
        if (isSuccess) {
            System.out.println("Learner account created successfully!");
        } else {
            System.out.println("Failed to create learner account.");
        }
    }
}
