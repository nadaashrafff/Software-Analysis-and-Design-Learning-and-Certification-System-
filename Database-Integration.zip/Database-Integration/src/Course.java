import java.util.Date;

public class Course {
    private int courseID;        // Primary key
    private String title;        // Course title
    private String description;  // Course description
    private Date startDate;      // Course start date

    // Default constructor
    public Course() {
    }

    // Existing constructors (if any)
    public Course(int courseID, Date startDate, String description, String title) {
        this.courseID = courseID;
        this.startDate = startDate;
        this.description = description;
        this.title = title;
    }

    // New constructor to match the required signature in CourseDA
    public Course(int courseID, Date startDate, String description, String title, String status) {
        this.courseID = courseID;
        this.startDate = startDate;
        this.description = description;
        this.title = title;
        
    }

    // Getters and Setters
    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    

    // Display details method
    public void displayDetails(String title, String description, Date startDate) {
        System.out.println("Title: " + title);
        System.out.println("Description: " + description);
        System.out.println("Start Date: " + startDate);
        System.out.println("-------------------");
    }
}
