// import java.util.List;

// public class CourseCatalogController {

//     /**
//      * Default constructor
//      */
//     public CourseCatalogController() {
//     }

//     /**
//      * Fetches available courses from the data access layer and sends them to the view.
//      * 
//      * @param title       The title of the course
//      * @param description The description of the course
//      * @param startDate   The start date of the course
//      * @param status      The status of the course
//      */
//     public List<Course> viewAvailableCourses() {
//         CourseDA courseDA = new CourseDA();
//         List<Course> courses = courseDA.viewAvailableCourses();

//         ViewCoursesScreen viewScreen = new ViewCoursesScreen();
//         viewScreen.viewAvailableCourses(courses);
//                 return courses;
//     }
// }

// import java.util.List;

// public class CourseCatalogController {

//     // Default constructor
//     public CourseCatalogController() {
//     }

//     // Fetches available courses from the data access layer and sends them to the view
//     public List<Course> viewAvailableCourses() {
//         CourseDA courseDA = new CourseDA();
//         List<Course> courses = courseDA.viewAvailableCourses(); // Fetch courses from CourseDA

//         // Pass the courses to the ViewCoursesScreen for display
//         ViewCoursesScreen viewScreen = new ViewCoursesScreen();
//         viewScreen.viewAvailableCourses(courses);

//         return courses;
//     }
// }


import java.util.List;

public class CourseCatalogController {

    // Default constructor
    public CourseCatalogController() {
    }

    // Fetches available courses from the data access layer and returns them
    public List<Course> viewAvailableCourses() {
        CourseDA courseDA = new CourseDA();
        return courseDA.viewAvailableCourses(); // Fetch courses only
    }
}
