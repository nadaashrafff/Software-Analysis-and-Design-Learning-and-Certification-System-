import java.util.Date;

public class CourseController {

    // Default constructor
    public CourseController() {
    }

    /**
     * Creates a new course and saves it to the database.
     * 
     * @param courseID    The ID of the course
     * @param startDate   The start date of the course
     * @param description The description of the course
     * @param title       The title of the course
     * @return True if the course was successfully created, false otherwise
     */
    public boolean createCourse(int courseID, Date startDate, String description, String title) {
        // Create a Course object
        Course course = new Course(courseID, startDate, description, title);

        // Save the course to the database using CourseDA
        CourseDA courseDA = new CourseDA();
        return courseDA.saveCourse(course);
    }
}
