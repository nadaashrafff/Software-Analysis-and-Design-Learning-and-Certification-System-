import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CourseDA {

    // Save a course using CourseController's parameters
    public boolean saveCourse(Course course) {
        String sql = "INSERT INTO Course (CourseID, Title, Description, StartDate) VALUES (?, ?, ?, ?)";

        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setInt(1, course.getCourseID());
            stmt.setString(2, course.getTitle());
            stmt.setString(3, course.getDescription());
            stmt.setDate(4, new java.sql.Date(course.getStartDate().getTime()));

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to retrieve available courses
    public List<Course> viewAvailableCourses() {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT CourseID, Title, Description, StartDate FROM Course";

        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Course course = new Course(
                    rs.getInt("CourseID"),
                    rs.getDate("StartDate"),
                    rs.getString("Description"),
                    rs.getString("Title")
                );
                courses.add(course);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courses;
    }
}
