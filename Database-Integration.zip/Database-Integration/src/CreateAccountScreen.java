import java.util.Date;
import java.util.Scanner;

public class CreateAccountScreen {
    private Scanner scanner;
    private AccountController accountController;

    // Constructor accepts a Scanner instance
    public CreateAccountScreen(Scanner scanner) {
        this.scanner = scanner;
        this.accountController = new AccountController(); // Initialize the AccountController
    }

    public void display() {
        System.out.println("Welcome to the Create Account Screen");
        System.out.println("Please choose an account type:");
        System.out.println("1. Learner");
        System.out.println("2. Instructor");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        if (choice == 1) {
            createLearnerAccount();
        } else if (choice == 2) {
            createInstructorAccount();
        } else {
            System.out.println("Invalid choice! Returning to the main menu.");
        }
    }

    private void createLearnerAccount() {
        System.out.println("Creating a Learner Account...");

        try {
            System.out.print("Enter Learner ID: ");
            int learnerID = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            System.out.print("Enter SSN: ");
            int ssn = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter Full Name (First Middle Last): ");
            String name = scanner.nextLine();

            System.out.print("Enter Email: ");
            String email = scanner.nextLine();

            System.out.print("Enter Gender (M/F): ");
            String gender = scanner.nextLine();

            System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
            String dobInput = scanner.nextLine();
            Date dob = java.sql.Date.valueOf(dobInput);

            // Call the AccountController to create a learner
            accountController.createLearner(learnerID, ssn, name, email, gender, dob);
        } catch (Exception e) {
            System.out.println("Error occurred while creating Learner account: " + e.getMessage());
        }
    }

    private void createInstructorAccount() {
        System.out.println("Creating an Instructor Account...");

        try {
            System.out.print("Enter Instructor ID: ");
            int instructorID = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            System.out.print("Enter SSN: ");
            int ssn = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter Full Name (First Middle Last): ");
            String name = scanner.nextLine();

            System.out.print("Enter Email: ");
            String email = scanner.nextLine();

            System.out.print("Enter Gender (M/F): ");
            String gender = scanner.nextLine();

            System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
            String dobInput = scanner.nextLine();
            Date dob = java.sql.Date.valueOf(dobInput);

            // Call the AccountController to create an instructor
            accountController.createInstructor(instructorID, ssn, name, email, gender, dob);
        } catch (Exception e) {
            System.out.println("Error occurred while creating Instructor account: " + e.getMessage());
        }
    }
}
