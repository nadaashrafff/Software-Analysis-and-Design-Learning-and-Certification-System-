// // import java.util.Scanner;
// // import java.util.Date;

// // public class CreateCourseScreen {

// //     public static void main(String[] args) {
// //         Scanner scanner = new Scanner(System.in);

// //         System.out.println("Welcome to the Create Course Screen!");

// //         // Collect course details
// //         System.out.print("Enter Course ID: ");
// //         int courseID = scanner.nextInt();
// //         scanner.nextLine(); // Consume newline

// //         System.out.print("Enter Start Date (yyyy-mm-dd): ");
// //         String startDateInput = scanner.nextLine();
// //         Date startDate = java.sql.Date.valueOf(startDateInput);

// //         System.out.print("Enter Description: ");
// //         String description = scanner.nextLine();

// //         System.out.print("Enter Title: ");
// //         String title = scanner.nextLine();

// //         // Create and save the course using CourseController
// //         CourseController courseController = new CourseController();
// //         boolean isSuccess = courseController.createCourse(courseID, startDate, description, title);

// //         // Display result
// //         if (isSuccess) {
// //             System.out.println("Course created successfully!");
// //         } else {
// //             System.out.println("Failed to create course.");
// //         }

// //         scanner.close();
// //     }
// // }

// import java.util.Scanner;

// public class CreateCourseScreen {

//     public void display() {
//         try (Scanner scanner = new Scanner(System.in)) {

//             System.out.println("Welcome to the Create Course Screen");
//             System.out.print("Enter Course ID: ");
//             int courseID = scanner.nextInt();
//             scanner.nextLine(); // Consume newline character
//             System.out.print("Enter Course Title: ");
//             String title = scanner.nextLine();
//             System.out.print("Enter Course Description: ");
//             String description = scanner.nextLine();
//             System.out.print("Enter Start Date (YYYY-MM-DD): ");
//             String startDate = scanner.nextLine();

//             // Use the collected data to create the course
//             CourseController courseController = new CourseController();
//             boolean result = courseController.createCourse(courseID, java.sql.Date.valueOf(startDate), description, title);

//             // Display success or failure message
//             if (result) {
//                 System.out.println("Course Created Successfully: " + title);
//             } else {
//                 System.out.println("Failed to create the course.");
//             }
//         } catch (Exception e) {
//             System.out.println("An error occurred while creating the course:");
//             e.printStackTrace();
//         }
//     }
// }

import java.util.Scanner;

public class CreateCourseScreen {
    private Scanner scanner;

    // Constructor accepts a Scanner instance
    public CreateCourseScreen(Scanner scanner) {
        this.scanner = scanner;
    }

    public void display() {
        System.out.println("Welcome to the Create Course Screen");

        try {
            // Collect course details
            System.out.print("Enter Course ID: ");
            int courseID = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            System.out.print("Enter Course Title: ");
            String title = scanner.nextLine();

            System.out.print("Enter Course Description: ");
            String description = scanner.nextLine();

            System.out.print("Enter Start Date (YYYY-MM-DD): ");
            String startDateInput = scanner.nextLine();


            // Parse the start date
            java.sql.Date startDate = java.sql.Date.valueOf(startDateInput);

            // Create a Course object using the constructor
            Course course = new Course(courseID, startDate, description, title);


            // Save the course using CourseDA
            CourseDA courseDA = new CourseDA();
            boolean isSaved = courseDA.saveCourse(course);

            // Display success or failure message
            if (isSaved) {
                System.out.println("Course created successfully!");
            } else {
                System.out.println("Failed to create the course. Please try again.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid date format. Please use YYYY-MM-DD.");
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while creating the course.");
            e.printStackTrace();
        }
    }
}



