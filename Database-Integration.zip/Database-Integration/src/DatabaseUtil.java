import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {
    // Connection string for the Educertify2 database
    private static final String CONNECTION_URL = "jdbc:sqlserver://LAPTOP-PUTEA40I:1433;databaseName=Educertify2;integratedSecurity=true;encrypt=true;trustServerCertificate=true;";

    // Method to establish and return a database connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(CONNECTION_URL);
    }
}


