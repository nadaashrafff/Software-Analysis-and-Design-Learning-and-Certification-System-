import java.util.Date;

public class Instructor {
    private int instructorID;
    private int SSN;
    private String fname;
    private String minit;
    private String lname;
    private String gender;
    private String major;
    private Date doB;
    private String email;

    // Getters and Setters
    public int getInstructorID() { return instructorID; }
    public void setInstructorID(int instructorID) { this.instructorID = instructorID; }

    public int getSSN() { return SSN; }
    public void setSSN(int SSN) { this.SSN = SSN; }

    public String getFname() { return fname; }
    public void setFname(String fname) { this.fname = fname; }

    public String getMinit() { return minit; }
    public void setMinit(String minit) { this.minit = minit; }

    public String getLname() { return lname; }
    public void setLname(String lname) { this.lname = lname; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }

    public Date getDoB() { return doB; }
    public void setDoB(Date doB) { this.doB = doB; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
