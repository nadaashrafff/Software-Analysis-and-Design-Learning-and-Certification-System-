import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InstructorDA {

    // Method to save an instructor's details in the database
    public boolean saveInstructorDetails(Instructor instructor) {
        String sql = "INSERT INTO Instructor (InstructorID, SSN, Fname, Minit, Lname, Gender, Major, DoB, Email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            // Set parameters for the SQL query
            stmt.setInt(1, instructor.getInstructorID());
            stmt.setInt(2, instructor.getSSN());
            stmt.setString(3, instructor.getFname());
            stmt.setString(4, instructor.getMinit());
            stmt.setString(5, instructor.getLname());
            stmt.setString(6, instructor.getGender());
            stmt.setString(7, instructor.getMajor());
            stmt.setDate(8, new java.sql.Date(instructor.getDoB().getTime()));
            stmt.setString(9, instructor.getEmail());

            // Execute the query
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // Return true if insertion was successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if an error occurred
        }
    }
}
