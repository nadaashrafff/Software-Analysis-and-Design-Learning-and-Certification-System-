import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LearnerDA {

    // Method to save a learner's details in the database
    public boolean saveLearnerDetails(Learner learner) {
        String sql = "INSERT INTO Learner (LearnerID, SSN, Fname, Minit, Lname, Gender, DoB, Email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            // Set parameters for the SQL query
            stmt.setInt(1, learner.getLearnerID());
            stmt.setInt(2, learner.getSSN());
            stmt.setString(3, learner.getFname());
            stmt.setString(4, learner.getMinit());
            stmt.setString(5, learner.getLname());
            stmt.setString(6, learner.getGender());
            stmt.setDate(7, new java.sql.Date(learner.getDoB().getTime()));
            stmt.setString(8, learner.getEmail());

            // Execute the query
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // Return true if insertion was successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if an error occurred
        }
    }
}
