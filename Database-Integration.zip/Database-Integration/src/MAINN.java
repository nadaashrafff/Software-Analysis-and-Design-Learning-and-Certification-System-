public class MAINN {
    public static void main(String[] args) {
        java.util.Scanner scanner = new java.util.Scanner(System.in); // Single Scanner instance
        int choice;

        do {
            System.out.println("1. Create Account");
            System.out.println("2. Create Course");
            System.out.println("3. View Available Courses");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    CreateAccountScreen createAccountScreen = new CreateAccountScreen(scanner); // Pass scanner
                    createAccountScreen.display();
                    break;
                case 2:
                    CreateCourseScreen createCourseScreen = new CreateCourseScreen(scanner); // Pass scanner
                    createCourseScreen.display();
                    break;
                case 3:
                    ViewCoursesScreen viewCoursesScreen = new ViewCoursesScreen();
                    viewCoursesScreen.display();
                    break;
                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 4);

        scanner.close();
    }
}
