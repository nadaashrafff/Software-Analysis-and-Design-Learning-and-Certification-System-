// import java.util.List;

// public class ViewCoursesScreen {

//     /**
//      * Default constructor
//      */
//     public ViewCoursesScreen() {
//     }

//     /**
//      * Displays the list of available courses.
//      * 
//      * @param title       The title of the course
//      * @param description The description of the course
//      * @param startDate   The start date of the course
//      * @param status      The status of the course
//      */
//     public void viewAvailableCourses(List<Course> courses) {
//         System.out.println("Available Courses:");
//         System.out.println("-------------------");
//         for (Course course : courses) {
//             course.displayDetails(
//                 course.getTitle(),
//                 course.getDescription(),
//                 course.getStartDate(),
//                 course.getStatus()
//             );
//         }
//     }
// }

// import java.util.List;

// public class ViewCoursesScreen {

//     // Default constructor
//     public ViewCoursesScreen() {
//     }

//     // Method to display available courses
//     public void viewAvailableCourses(List<Course> courses) {
//         System.out.println("Available Courses:");
//         if (courses == null || courses.isEmpty()) {
//             System.out.println("No courses available at the moment.");
//         } else {
//             for (Course course : courses) {
//                 System.out.println("----------------------------");
//                 System.out.println("Course ID: " + course.getCourseID());
//                 System.out.println("Title: " + course.getTitle());
//                 System.out.println("Description: " + course.getDescription());
//                 System.out.println("Start Date: " + course.getStartDate());
//                 System.out.println("----------------------------");
//             }
//         }
//     }

//     // New display method
//     public void display() {
//         CourseCatalogController courseCatalogController = new CourseCatalogController();
//         List<Course> courses = courseCatalogController.viewAvailableCourses();
//         viewAvailableCourses(courses);
//     }
// }
import java.util.List;

public class ViewCoursesScreen {

    // Default constructor
    public ViewCoursesScreen() {
    }

    // Method to display available courses
    public void viewAvailableCourses(List<Course> courses) {
        System.out.println("Available Courses:");
        if (courses == null || courses.isEmpty()) {
            System.out.println("No courses available at the moment.");
        } else {
            for (Course course : courses) {
                System.out.println("----------------------------");
                System.out.println("Course ID: " + course.getCourseID());
                System.out.println("Title: " + course.getTitle());
                System.out.println("Description: " + course.getDescription());
                System.out.println("Start Date: " + course.getStartDate());
                System.out.println("----------------------------");
            }
        }
    }

    // Display method for integration with MAINN
    public void display() {
        // Fetch courses using the CourseCatalogController
        CourseCatalogController courseCatalogController = new CourseCatalogController();
        List<Course> courses = courseCatalogController.viewAvailableCourses();

        // Use the existing method to display the courses
        viewAvailableCourses(courses);
    }
}
