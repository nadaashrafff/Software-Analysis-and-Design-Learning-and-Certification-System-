public class PushNotification implements Observer {
    private String deviceID;

    public PushNotification(String deviceID) {
        this.deviceID = deviceID;
    }

    @Override
    public void update(String gradeDetails) {
        System.out.println("Push notification sent to device " + deviceID + ": " + gradeDetails);
    }
}