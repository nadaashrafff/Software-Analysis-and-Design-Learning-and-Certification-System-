
public class SmsNotification implements Observer {
    private String phoneNumber;

    // Constructor with parameter
    public SmsNotification(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    // No-argument constructor
    public SmsNotification() {
        this.phoneNumber = "Unknown";
    }

    @Override
    public void update(String gradeDetails) {
        System.out.println("SMS sent to " + phoneNumber + ": " + gradeDetails);
    }
}