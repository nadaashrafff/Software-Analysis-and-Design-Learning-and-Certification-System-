public class main {
    public static void main(String[] args) {
        // Create Subject
        GradeNotifier gradeNotifier = new GradeNotifier();

        // Create Observers
        Observer emailObserver = new EmailNotification("student@example.com");
        Observer smsObserver = new SmsNotification("1234567890");
        Observer pushObserver = new PushNotification("Device123");

        // Register Observers
        gradeNotifier.addObserver(emailObserver);
        gradeNotifier.addObserver(smsObserver);
        gradeNotifier.addObserver(pushObserver);

        // Notify Observers
        gradeNotifier.setGradeDetails("Your grade for Course XYZ is A+.");

        // Remove an observer and notify again
        gradeNotifier.removeObserver(smsObserver);
        gradeNotifier.setGradeDetails("Your grade for Course XYZ is updated to A.");
    }
}