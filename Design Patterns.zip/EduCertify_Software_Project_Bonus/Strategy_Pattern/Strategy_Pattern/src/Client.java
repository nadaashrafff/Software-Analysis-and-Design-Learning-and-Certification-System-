

public class Client {
    public static void main(String[] args) {
        // Initialize context with a strategy
        Notification notification = new Notification(new EmailNotification1());

        // Send Email Notification
        notification.sendNotification("Welcome to EduCertify!");

        // Change strategy to SMS and send SMS Notification
        notification.setStrategy(new SMSNotification());
        notification.sendNotification("Your course has been updated!");

        // Change strategy to Push Notification and send Push Notification
        notification.setStrategy(new PushNotification());
        notification.sendNotification("You have a new message!");
    }
}