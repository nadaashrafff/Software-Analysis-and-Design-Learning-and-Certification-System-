
public class EmailNotification1 implements NotificationStrategy {
    @Override
    public void notify(String message) {
        System.out.println("Sending Email: " + message);
    }
}