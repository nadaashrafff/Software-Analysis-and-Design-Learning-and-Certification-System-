
public class Notification {
    private NotificationStrategy strategy;

    // Constructor to set the strategy
    public Notification(NotificationStrategy strategy) {
        this.strategy = strategy;
    }

    // Method to set/change the strategy at runtime
    public void setStrategy(NotificationStrategy strategy) {
        this.strategy = strategy;
    }

    // Method to perform notification using the current strategy
    public void sendNotification(String message) {
        if (strategy != null) {
            strategy.notify(message);
        } else {
            System.out.println("No strategy set for notification.");
        }
    }
}