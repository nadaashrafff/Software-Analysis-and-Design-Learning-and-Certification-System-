
public interface NotificationStrategy {
    void notify(String message);
}