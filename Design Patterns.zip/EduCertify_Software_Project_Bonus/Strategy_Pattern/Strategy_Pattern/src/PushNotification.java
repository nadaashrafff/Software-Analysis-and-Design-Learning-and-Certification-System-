
public class PushNotification implements NotificationStrategy {
    @Override
    public void notify(String message) {
        System.out.println("Sending Push Notification: " + message);
    }
}