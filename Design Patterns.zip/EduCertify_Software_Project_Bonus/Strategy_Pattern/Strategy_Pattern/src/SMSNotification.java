
public class SMSNotification implements NotificationStrategy {
    @Override
    public void notify(String message) {
        System.out.println("Sending SMS: " + message);
    }
}